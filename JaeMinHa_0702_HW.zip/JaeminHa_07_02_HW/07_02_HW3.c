#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


int result = 3;

	char music[9];								//���ڿ� ����
	char asc[9] = { "cdefgabC" };
	char des[9] = { "Cbagfedc" };

int main() {
	printf("�� �Է�\n");
	scanf("%s", &music);
	int num1 = 0, num2 = 0;
	
		
		for (int i = 0; i < 8; i++) {			//��������� �� num1++
			if (music[i] == asc[i])
				num1++;
			 if (music[i] == des[i])			//�ݴ�� num2++
				num2++;	
		}
	
	result = add(num1, num2);				//�Լ�
	
	switch (result) {						//switch�� ����Ʈ
	case 1 :
		printf("ascending");
		break;
	case 2 :
		printf("descending");
		break;
	case 3 :
		printf("mixed");
	}
}
int add(int x, int y)				//�Լ�
{
	if (x == 8)
		return 1;
	else if (y == 8)
		return 2;
	else
		return 3;
}