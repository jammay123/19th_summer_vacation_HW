#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct _Node
{
	int data;
	struct _Node* next;
}node;
typedef struct QueueList
{
	node* head;
	node* tail;
	int size;
}QueueList;
node* create_newnode(int data)
{
	node* newnode = (node*)malloc(sizeof(node));
	newnode->data = data;
	newnode->next = NULL;
	return newnode;
}
void init(QueueList* queue)
{
	queue->head = NULL;
	queue->tail = NULL;
	queue->size = 0;
}
void Enqueue(QueueList* queue, int data)
{
	node* newnode = create_newnode(data);
	if (queue->size == 0)		//ť�� ������� head = tail = newnode �̴�.
		queue->head = newnode;
	else
		queue->tail->next = newnode;		//ť�� ������� ���� �� tail �� newnode ����
	queue->tail = newnode;
	queue->size++;	
}
void Dequeue(QueueList* queue)
{

	if (queue->size == 0)
	{
		printf("ť�� ����ֽ��ϴ�.");
		return 0;
	}
	node* temp = queue->head;		//������ ���� temp�� �����ǰ� �޷θ� ����
	printf("\n%d", queue->head->data);
	queue->head = temp->next;
	free(temp);
	queue->size--;
}
void size(QueueList* queue)
{
	printf("\n%d", queue->size);
}
void front(QueueList* queue)
{
	if (queue->size == 0)
		printf("ť�� ����ֽ��ϴ�.\n");
	printf("\n%d", queue->head->data);
}
void rear(QueueList* queue)
{
	if (queue->size == 0)
		printf("ť�� ����ֽ��ϴ�.\n");
	printf("\n%d", queue->tail->data);
}

void isEmpty(QueueList* queue)
{
	if (queue->size == 0)
		printf("true\n");
	else
		printf("false\n");
}
void printQueue(QueueList* queue)
{
	if (queue->size == 0)
		printf("ť�� ����ֽ��ϴ�.\n");
	node* temp = queue->head;
	while (temp != NULL)
	{
		printf("%2d", temp->data);
		temp = temp->next;
	}
	printf("\n");
}
int main()
{
	QueueList queue;
	init(&queue);
	printf("���ɾ �Է��ϼ��� : ");

	while (1)
	{
		int n = 0;
		char input[20] = { 0, };
		scanf("%s", input);


		if (!strcmp(input, "Enqueue"))
		{
			printf("Enqueue�� �����Ͱ��� �Է��ϼ���.");
			scanf("%d", &n);
			Enqueue(&queue, n);
			printQueue(&queue);
		}
		if (!strcmp(input, "Dequeue"))
		{
			Dequeue(&queue);
		}
		if (!strcmp(input, "size"))
		{
			size(&queue);
		}
		if (!strcmp(input, "front"))
		{
			front(&queue);
		}
		if (!strcmp(input, "rear"))
		{
			rear(&queue);
		}
		if (!strcmp(input, "isEmpty"))
		{
			isEmpty(&queue);
		}
		if (!strcmp(input, "printQueue"))
		{
			printQueue(&queue);
		}
	}
}