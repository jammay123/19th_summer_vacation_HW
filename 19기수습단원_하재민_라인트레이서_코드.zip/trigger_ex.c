
/*
 * test.c
 *
 * Created: 2024-08-08 오후 1:29:17
 *  Author: jmha0
 */ 
#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

unsigned int capture_value = 0;
unsigned int rising_edge = 1;

#include "LCD_Text.h"

unsigned int distance;

ISR(TIMER3_CAPT_vect)
 {
   if (rising_edge) 
   {
      TCNT3 = 0;  // 타이머 카운터 리셋
      TCCR3B &= ~(1 << ICES3);
      rising_edge = 0;
      } 
      else
      {
      capture_value = ICR3;
      distance = (capture_value / 2) * 0.034;
      
      TCCR3B |= (1 << ICES3);
      rising_edge = 1;
      
      
   }
}

void timer3_input_capture_init(void) 
{
   // 입력 캡처 핀 설정 (PE3/ICP1 핀 입력 모드)
   DDRD &= ~(1 << PE7);

   TCCR3A = 0;

   TCCR3B |= (1 << ICES3);  // 상승 에지에서 캡처
   TCCR3B |= (1 << ICNC3);  // 노이즈 캔슬러 활성화
   TCCR3B |= (1 << CS31);   // 프리스케일러를 8로 설정 (타이머 시작)

   ETIMSK |= (1 << TICIE3);

   sei();
}

void trigger_pulse(void) 
{
   // 트리거 핀 설정 (출력 모드)
   DDRE |= (1 << PE3);
   
   // 트리거 핀을 LOW로 설정
   PORTE &= ~(1 << PE3);
   _delay_us(20);
   
   // 트리거 핀을 HIGH로 설정
   PORTE |= (1 << PE3);
   _delay_us(100);
   
   // 트리거 핀을 다시 LOW로 설정
   PORTE &= ~(1 << PE3);
}

int main(void) 
{


   timer3_input_capture_init();
   
   lcdInit();
	lcdClear();
   while (1)
    {   
      trigger_pulse();
      
      _delay_ms(200);
      
      // 속도는 약 340 m/s (0.034 cm/us)
      // 왕복 시간이므로 2로 나눔p
      
      lcdNumber(0,0,distance);
      _delay_ms(100);
	  lcdClear();
      
      capture_value = 0;
      distance = 0;
   }
}
