﻿#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "LCD_Text.h"

void adc_init()
{
	DDRF = 0x00;           // PF를 입력으로 설정
	ADMUX = 0x40;          // AVCC를 기준 전압으로 설정
	ADCSRA = 0x87;         // ADC를 활성화하고 prescaler를 128로 설정
	SREG = 0x80;           // 전역 인터럽트 활성화 (필요한 경우)
}

unsigned int read_adc(unsigned int channel)
{
	ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);  // 원하는 채널 선택
	ADCSRA |= (1 << ADSC);                      // 변환 시작
	while (ADCSRA & (1 << ADSC));               // 변환 완료 대기
	return ADC;                                 // ADC 값 반환
}

int adc_max[7] = {0,};
int adc_min[7] = {1023,1023,1023,1023,1023,1023,1023};
int ir_adc_arr[7];

void max_min(void)
{
	for(int i = 0; i < 7; i++)
	{
		if(ir_adc_arr[i] > 0)
		{
			if(adc_max[i] < ir_adc_arr[i])
			adc_max[i] = ir_adc_arr[i];
			if(adc_min[i] > ir_adc_arr[i])
			adc_min[i] = ir_adc_arr[i];
		}
	}
}

double avr_adc[7];
int fix_adc_min[7] = {0,};
int fix_adc_max[7] = {0,};

void get_avr_adc(void)
{
	for(int i = 0; i < 7; i++)
	{
		if (fix_adc_max[i] != fix_adc_min[i]) { // 분모가 0이 되는 것을 방지
			avr_adc[i] = (double)(ir_adc_arr[i] - fix_adc_min[i]) / (fix_adc_max[i] - fix_adc_min[i]);
			} else {
			avr_adc[i] = 0;
		}
	}
}

void motor_init(void)
{
	TCCR1A = 0xA2;
	TCCR1B = 0x1A;
	TCCR1C = 0x00;
	
	ICR1 = 399;
	TCNT1 = 0x00;
}

ISR(INT0_vect)
{
	for(int i = 0; i < 7; i++)
	{
		fix_adc_max[i] = adc_max[i];
		fix_adc_min[i] = adc_min[i];
	}
	lcdClear();
	lcdNumber(0, 0, fix_adc_min[4]);
	lcdNumber(1, 0, fix_adc_max[4]);
}
int field = 100;      // 0 : 흰색, 1 : 검은색
ISR(INT1_vect)
{
	field = 0;
}
unsigned int capture_value = 0;
unsigned int rising_edge = 1;
unsigned int distance;
ISR(TIMER3_CAPT_vect)
{
	if(rising_edge)
	{
		TCNT3 = 0;
		TCCR3B &= ~(1 << ICES3);
		rising_edge = 0;
	}
	else
	{
		capture_value = ICR3;
		distance = (capture_value / 2) * 0.034;
		
		TCCR3B |= (1<<ICES3);
		rising_edge = 1;
	}
}

void timer3_init(void)
{
	DDRD &= ~(1 << PE7);
	
	TCCR3A = 0;
	
	TCCR3B |= (1<<ICES3);
	TCCR3B |= (1<<ICNC3);
	TCCR3B |= (1<<CS31);
	
	ETIMSK |= (1<< TICIE3);
	
}

void trigger(void)
{
	DDRE |= (1<< PE3);
	
	PORTE &= ~(1<<PE3);
	_delay_us(20);
	
	PORTE |= (1<<PE3);
	_delay_us(100);
	
	PORTE &= ~(1<<PE3);
}

void w_linetrace(void)		//검은색 배경, 하얀 라인
{
	 if((avr_adc[1] > 0.1) && (avr_adc[0] < 0.1))		//좌회전
	 {
		 if((avr_adc[2] < 0.1) || (avr_adc[3] < 0.1))
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0;
			 OCR1B = ICR1 * 0.9;
		 }
		 else
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0;
			 OCR1B = ICR1 * 0.9;
			 PORTB = (PORTB & 0xF0) | 0x0A;
			 OCR1A = ICR1 * 0.9;
			 OCR1B = ICR1 * 0;
		 }
	 }
	 else if((avr_adc[1] < 0.1) && (avr_adc[0] > 0.1))		//우회전
	 {
		 if((avr_adc[4] < 0.1) || (avr_adc[5] < 0.1))
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0.9;
			 OCR1B = ICR1 * 0;
		 }
		 else
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0.9;
			 OCR1B = ICR1 * 0;
			 PORTB = (PORTB & 0xF0) | 0x0A;
			 OCR1A = ICR1 * 0;
			 OCR1B = ICR1 * 0.9;
		 }
	 }
	 else if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
	 {
		 if((avr_adc[1] < 0.1) && (avr_adc[0] < 0.1))
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0.7;
			 OCR1B = ICR1 * 0.7;
		 }
	 }
	 else if((avr_adc[1] < 0.05) && (avr_adc[2] < 0.05) && (avr_adc[3] < 0.05) && (avr_adc[4] < 0.05) && (avr_adc[5] < 0.05) && (avr_adc[6] < 0.05) && (avr_adc[0] < 0.05))      //후진(3종류)
	 {
		 if(avr_adc[1] < 0)
		 {
			 PORTB = (PORTB & 0xF0) | 0x0A;
			 OCR1A = ICR1 * 0.5;
			 OCR1B = ICR1 * 0.8;
		 }
		 else if(avr_adc[0] < 0)
		 {
			 PORTB = (PORTB & 0xF0) | 0x0A;
			 OCR1B = ICR1 * 0.5;
			 OCR1A = ICR1 * 0.8;
		 }
		 else
		 {
			 PORTB = (PORTB & 0xF0) | 0x0A;
			 OCR1A = ICR1 * 0.6;
			 OCR1B = ICR1 * 0.6;
		 }
	 }
}
void play_T(void)		//차단바 나온 후에 오른쪽으로만 가면 되므로 오른쪽, 직진, 올블랙일때 후진만 넣음(T자 구간 한번에 가능)
{
	if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))
	{
		 if((avr_adc[1] < 0.1) && (avr_adc[6] < 0.1))
		 {
			 PORTB = (PORTB & 0xF0) | 0x05;
			 OCR1A = ICR1 * 0.9;
			 OCR1B = ICR1 * 0.9;
		 }
		else if((avr_adc[0] > 0.1) && (avr_adc[5] > 0.1))
		{
			PORTB = (PORTB & 0xF0) | 0x09;
			OCR1A = ICR1 * 0.9;
			OCR1B = ICR1 * 0.5;
			_delay_ms(800);
		}
	}
	else if((avr_adc[1] < 0.1) && (avr_adc[2] < 0.1) && (avr_adc[3] < 0.1) && (avr_adc[4] < 0.1) && (avr_adc[5] < 0.1) && (avr_adc[6] < 0.1))
	{
		 PORTB = (PORTB & 0xF0) | 0x0A;
		 OCR1A = ICR1 * 0.9;
		 OCR1B = ICR1 * 0.9;
		 _delay_ms(900);
	}
}


int main(void)
{
	DDRD = 0x00;
	DDRB = 0x6F;
	
	EIMSK = (1 << INT0) | (1<<INT1);
	EICRA = (0 << ISC01) | (0 << ISC00) | (1 << ISC10) | (0 << ISC11); 
	
	adc_init();
	motor_init();
	lcdInit();
	lcdClear();
	timer3_init();
	
	char buffer[7][10];
	int whiteline_cnt = 0;
	int tag_bar = 0;
	
	while (1)
	{
		lcdClear();
		max_min();

		// PF1~PF6 핀에 해당하는 ADC 값을 읽어서 배열에 저장
		for (int i = 0; i < 7; i++)
		{
			unsigned int adc_value = read_adc(i);  // PF1~6
			ir_adc_arr[i] = adc_value;
		}
		unsigned int psd_value = read_adc(7);      //psd값 받기(pf7)

		get_avr_adc();
		
		for(int i = 0; i < 7; i++)
		{
			sprintf(buffer[i], "%.2lf", avr_adc[i]); // 각 채널의 값을 buffer에 저장
		}
		trigger();
		_delay_ms(50);
		if(field == 0)
		{	

			// 읽은 값을 LCD에 출력
			lcdString(0, 0, buffer[1]);  // PF1 (ADC1)
			lcdString(0, 5, buffer[2]);  // PF2 (ADC2)
			lcdString(0, 10, buffer[3]);  // PF3 (ADC3)
			lcdString(1, 0, buffer[4]);  // PF4 (ADC4)
			lcdString(1, 4, buffer[5]);  // PF5 (ADC5)
			lcdString(1, 8, buffer[6]);  // PF6 (ADC6)
			lcdString(1, 12, buffer[0]);	//PF0

		 if((avr_adc[1] < 0.05) || (avr_adc[0] < 0.05))        //field 바뀌는 조건
          {
             if((avr_adc[4] < 0.05) || (avr_adc[3] < 0.05))
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0;
                OCR1B = ICR1 * 0;
                _delay_ms(1000);      //field 바뀌었는지 정지 모션
                field = 1;
             }
          }
          else if((avr_adc[1] < 0.5) && (avr_adc[0] > 0.5))      //좌회전
          {
             if(avr_adc[2] > 0.5)
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1B = ICR1 * 0.7;
                OCR1A = ICR1 * 0;
             }
             else if(avr_adc[3] > 0.5)
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1B = ICR1 * 0.8;
                OCR1A = ICR1 * 0;
             }
             else 
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1B = ICR1 * 0.7;
                OCR1A = ICR1 * 0;
                PORTB = (PORTB & 0xF0) | 0x0A;
                OCR1B = ICR1 * 0;
                OCR1A = ICR1 * 0.7;
             }
          }
          else if((avr_adc[1] > 0.5) && (avr_adc[6] < 0.5))      //우회전
          {
             if(avr_adc[5] > 0.5)
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0.6;
                OCR1B = ICR1 * 0;
             }
             else if(avr_adc[4] > 0.5)
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0.7;
                OCR1B = ICR1 * 0;
             }
             else if((avr_adc[3] > 0.5) || (avr_adc[2] > 0.5) || (avr_adc[1] > 0.5))
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0.7;
                OCR1B = ICR1 * 0;
                PORTB = (PORTB & 0xF0) | 0x0A;
                OCR1A = ICR1 * 0;
                OCR1B = ICR1 * 0.7;
             }
          }
          else if((avr_adc[1] < 0.5) && (avr_adc[0] < 0.5))      //바코드(PF0이 오른쪽 끝, PF1이 왼쪽 끝)
          {
             if((avr_adc[4] < 0.5) || (avr_adc[3] < 0.5) || (avr_adc[2] < 0.5) || (avr_adc[5] < 0.5) || (avr_adc[1] < 0.5))
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0.8;
                OCR1B = ICR1 * 0.8;
                _delay_ms(200);
             }

          }
          else if ((avr_adc[4] < 0.5) || (avr_adc[3] < 0.5))      //가운데
          {
             if((avr_adc[1] > 0.5) && (avr_adc[0] > 0.5))
             {
                PORTB = (PORTB & 0xF0) | 0x05;
                OCR1A = ICR1 * 0.6;
                OCR1B = ICR1 * 0.6;
             }
          }
          else if((avr_adc[1] > 0.65) && (avr_adc[2] > 0.65) && (avr_adc[3] > 0.65) && (avr_adc[4] > 0.65) && (avr_adc[5] > 0.65) && (avr_adc[6] > 0.65) && (avr_adc[0] > 0.65))      //후진(3종류)
          {
             if(avr_adc[1] > 0.8)
             {
                PORTB = (PORTB & 0xF0) | 0x0A;
                OCR1A = ICR1 * 0.6;
                OCR1B = ICR1 * 0.7;
             }
             else if(avr_adc[0] > 0.8)
             {
                PORTB = (PORTB & 0xF0) | 0x0A;
                OCR1B = ICR1 * 0.6;
                OCR1A = ICR1 * 0.7;
             }
             else
             {
                PORTB = (PORTB & 0xF0) | 0x0A;
                OCR1A = ICR1 * 0.6;
                OCR1B = ICR1 * 0.6;
             }
          }

		}
	
			 

		//------------------------------------------------------------------------------------------------------------------바닥 변화
	else if(field == 1)
		{
			lcdClear();
			lcdNumber(0,0,whiteline_cnt);
			lcdNumber(1,0,distance);
			lcdNumber(1,7, psd_value);
			
			if(whiteline_cnt == 0)
			{		
				if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
				{
					if((avr_adc[2] > 0.1) || (avr_adc[5] > 0.1))
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.75;
						OCR1B = ICR1 * 0.8;
						_delay_ms(800);
						whiteline_cnt = 1;
					}
				}
				else
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.8;
					OCR1B = ICR1 * 0.7;
				}
			}
			else if(whiteline_cnt == 1)
			{
				if(distance < 30)
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.5;
					OCR1B = ICR1 * 0.8;
				}
				else
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.8;
					OCR1B = ICR1 * 0.5;
				}
				if((avr_adc[1] > 0.15) || (avr_adc[6] > 0.15) || (avr_adc[4] > 0.15))
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.8;
					OCR1B = ICR1 * 0.8;
					_delay_ms(700);		//트레이싱을 위한 강제전진
					whiteline_cnt = 2;
				}
			}
			else if(whiteline_cnt == 2)		//흰선 따라가기(차단바 전)
			{		
			    if((avr_adc[1] > 0.1) && (avr_adc[0] < 0.1))		//좌회전
				{
					if(avr_adc[2] < 0.1)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0.9;
					}
					else if(avr_adc[3] < 0.1)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0.9;
					}
					else
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0.7;
						PORTB = (PORTB & 0xF0) | 0x0A;
						OCR1A = ICR1 * 0.7;
						OCR1B = ICR1 * 0;
					}
				}
				else if((avr_adc[1] < 0.1) && (avr_adc[0] > 0.1))		//우회전
				{
					if(avr_adc[6] < 0.1)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.6;
						OCR1B = ICR1 * 0;
					}
					else if(avr_adc[5] < 0.1)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.7;
						OCR1B = ICR1 * 0;
					}
					else
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.7;
						OCR1B = ICR1 * 0;
						PORTB = (PORTB & 0xF0) | 0x0A;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0.7;
					}
				}
				else if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
				{
					if((avr_adc[1] < 0.1) && (avr_adc[0] < 0.1))
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.6;
						OCR1B = ICR1 * 0.6;
					}
				}
				else if((avr_adc[1] < 0.05) && (avr_adc[2] < 0.05) && (avr_adc[3] < 0.05) && (avr_adc[4] < 0.05) && (avr_adc[5] < 0.05) && (avr_adc[6] < 0.05) && (avr_adc[0] < 0.05))      //후진(3종류)
				{
					if(avr_adc[1] < 0)
					{
						PORTB = (PORTB & 0xF0) | 0x0A;
						OCR1A = ICR1 * 0.6;
						OCR1B = ICR1 * 0.7;
					}
					else if(avr_adc[0] < 0)
					{
						PORTB = (PORTB & 0xF0) | 0x0A;
						OCR1B = ICR1 * 0.6;
						OCR1A = ICR1 * 0.7;
					}
					else
					{
						PORTB = (PORTB & 0xF0) | 0x0A;
						OCR1A = ICR1 * 0.6;
						OCR1B = ICR1 * 0.6;
					}
				}
				
				if((psd_value >= 220) && (avr_adc[3] > 0.1) && (avr_adc[4] > 0.1))
				{
					if((avr_adc[1] < 0.1) && (avr_adc[6] < 0.1))
					{
					PORTB = (PORTB & 0xF0) | 0x05;		//확인용 정지 모션
					OCR1A = ICR1 * 0;
					OCR1B = ICR1 * 0;
					_delay_ms(1000);
					whiteline_cnt = 3;
					}
				}	
			}
			else if(whiteline_cnt == 3)
			{
				if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.7;
					OCR1B = ICR1 * 0.7;
				}
				else if((avr_adc[5] > 0.1) && (avr_adc[2] < 0.1)) 		//직진
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.7;
					OCR1B = ICR1 * 0.6;
				}
				else if((avr_adc[5] < 0.1) && (avr_adc[2] > 0.1)) 		//직진
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.6;
					OCR1B = ICR1 * 0.7;
				}
				else if((avr_adc[6] > 0.1) && (avr_adc[1] < 0.1))
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.8;
					OCR1B = ICR1 * 0.6;
				}
				else if((avr_adc[1] > 0.1) && (avr_adc[6] < 0.1))
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.6;
					OCR1B = ICR1 * 0.8;
				}
				
				if((avr_adc[1] > 0.1) && (avr_adc[6] > 0.1) && (avr_adc[3] > 0.1) && (avr_adc[4] > 0.1))
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0;
					OCR1B = ICR1 * 0;
					whiteline_cnt = 4;
				}
			}
			else if(whiteline_cnt == 4)
			{
				if(psd_value > 400)
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0;
					OCR1B = ICR1 * 0;
					tag_bar = 1;
				}
				else if(psd_value <= 400)
				{
					if(tag_bar == 0)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0;
					}
					else if(tag_bar == 1)
					{
						if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.7;
							OCR1B = ICR1 * 0.7;
						}
						else if((avr_adc[5] > 0.1) && (avr_adc[2] < 0.1)) 		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.7;
							OCR1B = ICR1 * 0.6;
						}
						else if((avr_adc[5] < 0.1) && (avr_adc[2] > 0.1)) 		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.6;
							OCR1B = ICR1 * 0.7;
						}
						else if((avr_adc[6] > 0.1) && (avr_adc[1] < 0.1))
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.8;
							OCR1B = ICR1 * 0.6;
						}
						else if((avr_adc[1] > 0.1) && (avr_adc[6] < 0.1))
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.6;
							OCR1B = ICR1 * 0.8;
						}
					}
				}
				if((avr_adc[1] < 0.1) && (avr_adc[0] < 0.1) && (avr_adc[4] < 0.1) && (avr_adc[3] < 0.1) && (avr_adc[2] < 0.1) && (avr_adc[5] < 0.1) && (avr_adc[6] < 0.1))		//올 블랙을 봤을 때, 파킹
				{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0.9;
						OCR1B = ICR1 * 0.9;
						_delay_ms(700);
						PORTB = (PORTB & 0xF0) | 0x06;
						OCR1A = ICR1 * 0.9;
						OCR1B = ICR1 * 0.9;
						_delay_ms(1100);
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0;
						_delay_ms(5000);
						whiteline_cnt = 5;
				}
			}
			else if(whiteline_cnt == 5)
			{
				if(psd_value > 400)
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0;
					OCR1B = ICR1 * 0;
					tag_bar = 2;
				}
				else if(psd_value <= 400)
				{
					if(tag_bar == 1)
					{
						PORTB = (PORTB & 0xF0) | 0x05;
						OCR1A = ICR1 * 0;
						OCR1B = ICR1 * 0;
					}
					else if(tag_bar == 2)
					{
						if((avr_adc[3] > 0.1) || (avr_adc[4] > 0.1))		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.7;
							OCR1B = ICR1 * 0.7;
						}
						else if((avr_adc[5] > 0.1) && (avr_adc[2] < 0.1)) 		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.7;
							OCR1B = ICR1 * 0.6;
						}
						else if((avr_adc[5] < 0.1) && (avr_adc[2] > 0.1)) 		//직진
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.6;
							OCR1B = ICR1 * 0.7;
						}
						else if((avr_adc[6] > 0.1) && (avr_adc[1] < 0.1))
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.8;
							OCR1B = ICR1 * 0.6;
						}
						else if((avr_adc[1] > 0.1) && (avr_adc[6] < 0.1))
						{
							PORTB = (PORTB & 0xF0) | 0x05;
							OCR1A = ICR1 * 0.6;
							OCR1B = ICR1 * 0.8;
						}
					}
				}
				if((avr_adc[2] < 0.1) && (avr_adc[6] > 0.1) && (avr_adc[4] > 0.1))
				{
					PORTB = (PORTB & 0xF0) | 0x05;
					OCR1A = ICR1 * 0.9;
					OCR1B = ICR1 * 0;
					_delay_ms(800);
					whiteline_cnt = 6;
				}
			}
			
			else if(whiteline_cnt == 6)
			{
				play_T();
			}
		}
		capture_value = 0;
	}
}



