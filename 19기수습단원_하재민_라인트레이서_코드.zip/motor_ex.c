﻿/*
 * HW_002.c
 *
 * Created: 2024-08-07 오후 4:22:37
 *  Author: msi
 */ 

#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "LCD_Text.h"
float adcValue = 0;
float motor_adc = 0;

char speed[16] = {0, };

int main(void)
{
   DDRB = 0x6F;
   //모터 설정
   TCCR3A = 0xA2;
   TCCR3B = 0x1A;
   TCCR1C = 0x00;

   ICR3 = 199;
   TCNT3 = 0x00;
   
   // LCD
   DDRF = 0x00;
   ADMUX = 0x40;
   ADCSRA = 0x87;

   SREG = 0x80;

   //adcValue 설정
   lcdInit();
   lcdClear();
   
   while (1)
   {
      ADCSRA |= (1 << ADSC);
      while(ADCSRA &(1 <<ADSC));
      adcValue = ADC;
      
      //adc값을 0. 몇몇으로 나타내기
      motor_adc = adcValue/1023;
      PORTB = (PORTB & 0xF0) | 0x05;
      //모터 작동
      OCR1A = ICR3 * motor_adc;
      OCR1B = ICR3* motor_adc;
      //관련 출력
      
      // 실수는 문자
      sprintf(speed, "%.4f", motor_adc);
      
      lcdString(0, 0, speed);
      
      _delay_ms(100);
      lcdClear();
   }
}
